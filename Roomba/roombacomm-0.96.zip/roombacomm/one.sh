./runit.sh roombacomm.Spiro2 /dev/tty.RooTooth-COM0-3 240  401 1 1230 1000
